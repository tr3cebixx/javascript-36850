6-4 lo que vengo sufriendo con funciones, por fin las hice funcionar. primera entrega del proyecto final.

4-4 pude solucionar solo el problema arrays y el problema general de mis condicionales, creo que ahora esta bien.

27-3 estoy re manija con la idea esta del rpg, creo que va a ser mi proyecto.

24-3 aca voy a ir dejando los desafios.